
# THIS FILE IS GENERATED FROM NUMPY SETUP.PY
#
# To compare versions robustly, use `numpy.lib.NumpyVersion`
short_version = '1.16.0'
version = '1.16.0'
full_version = '1.16.0'
git_revision = '971e2e89d08deeae0139d3011d15646fdac13c92'
release = True

if not release:
    version = full_version
